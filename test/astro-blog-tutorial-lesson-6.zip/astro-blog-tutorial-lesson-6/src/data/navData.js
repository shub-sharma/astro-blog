const navData = [
  {
    name: "About",
    path: "/about/",
  },
  {
    name: "Blog",
    path: "/blog/",
  },
]

export default navData;